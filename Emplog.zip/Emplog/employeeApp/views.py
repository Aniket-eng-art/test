from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.shortcuts import HttpResponse 
from django.contrib.auth import authenticate
from django.core.mail import send_mail 
from django.contrib import messages 
from Emplog import settings
# Create your views here.
def login(request):
    if request.method=='GET':
        request.session["cnt"]=0
        return render(request,"login.html")
    elif request.method=="POST":
        u=request.POST["uname"]
        p=request.POST["pas"]
        msg=""
        if(u=="abc" and p=="1234"):
            msg="Login Success"
            return HttpResponse("<h2>Success</h2>")

        else:
            msg="Login Fail"
        cnt=int(request.session["cnt"])
        if(cnt==3):
            request.session["cnt"]=""    
            SendEmailCall()
            return HttpResponse("<h2>Finished</h2>")
        else:   
            cnt=cnt+1
            request.session["cnt"]=cnt


            return render(request,"login.html",{"msg":"Total Attempts="+str(cnt)})

def SendEmailCall():
    to="kulkarnianiket530@gmail.com"
    res=send_mail('Attempts Exceed',"Login Attempted 3 times , your account locked",settings.EMAIL_HOST_USER,[to])
